##本地开发

安装依赖：`npm install`<br/>

本地开发：

    `npm run build:dev`

    `npm start`
    
生产环境打包：

    `npm run build:prod`

Element-ui 按需加载 /app/src/element

v-charts 按需加载 /app/src/v-charts

config.json配置：

port: 本地调试服务端口

assetsPath: 静态资源文件相对位置
