import Vue from 'vue';
import ElementUI from './element/index'
import vCharts from './v-chars/index'
import baseStyle from './components/style/base.css';
import 'element-ui/lib/theme-chalk/index.css'
import axios from 'axios'
import moment from 'moment'

import main from './pages/index.vue';

Vue.use(ElementUI);
Vue.use(vCharts);

Vue.filter('NumFormat', function(value) {
  if(!value) return '0';

  let intPart =  Number(value)|0; //获取整数部分
  let intPartFormat = intPart.toString().replace(/(\d)(?=(?:\d{3})+$)/g, '$1,'); //将整数部分逢三一断

  let floatPart = ""; //预定义小数部分
  let value2Array = value.toString().split(".");

  //=2表示数据有小数位
  if(value2Array.length === 2) {
    floatPart = value2Array[1].toString(); //拿到小数部分

    if(floatPart.length === 1) { //补0
      return intPartFormat + "." + floatPart + '0';
    } else {
      return intPartFormat + "." + floatPart;
    }

  } else {
    return intPartFormat + floatPart;
  }

});
//加入数据格式处理moment.js
Vue.prototype.$moment = moment;
moment.locale('zh-cn');

Vue.prototype.$axios = axios;
Vue.prototype.$axios.defaults.baseURL = '/management/api/statistics/nums';


Vue.prototype.$rootVm=new Vue({
  el: '#app',
  render: h => h(main)
});
