// 导入自己需要的组件
import { Select, Container, DatePicker, Header, Dropdown, Main, Button, Option, Row, Col ,Collapse ,CollapseItem ,Loading} from 'element-ui';

const element = {
  install: function (Vue) {
    Vue.use(Select);
    Vue.use(Container);
    Vue.use(DatePicker);
    Vue.use(Header);
    Vue.use(Dropdown);
    Vue.use(Main);
    Vue.use(Button);
    Vue.use(Option);
    Vue.use(Row);
    Vue.use(Col);
    Vue.use(Collapse);
    Vue.use(Loading);
    Vue.use(CollapseItem);
  }
};

export default element;
