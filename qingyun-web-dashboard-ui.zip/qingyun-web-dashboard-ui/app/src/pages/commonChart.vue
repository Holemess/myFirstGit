<template>
  <div v-loading="loading" class="commonMain">
    <el-row class="el-row-spe" v-if="modelData.title!=='注册统计'">
      <el-col :span="24" class="manage-title">
        <div class="grid-content">
          <span class="manage-title-span">{{modelData.title}}</span>
        </div>
      </el-col>
    </el-row>
    <el-row class="el-row-component el-row-spe">
      <el-col :span="5">
        <div class="grid-content">
          <div v-if="processData.totalVal >= 0">
            <label class="register-total-label register-first-label">累计总收入</label>
            <span class=" manage-in-money">￥{{processData.totalVal|NumFormat}}</span>
          </div>
          <div v-if="processData.todayVal >= 0">
            <label class="register-total-label register-other-label">今日总收入</label>
            <span class=" manage-in-money">￥{{processData.todayVal|NumFormat}}</span>
            <div class="left-list-div">
              <i class="el-icon-caret-top green-icon" v-if="processData.tvRate"></i>
              <i class="el-icon-caret-bottom red-icon" v-if="!processData.tvRate"></i>
              <span :class="processData.tvRate?'data-percent-number-up':'data-percent-number-down'">{{processData.tvRateNum}}</span>
              <label class="data-income-com">同比昨日</label>
            </div>
          </div>
          <div v-if="processData.totalNum >= 0">
            <label class="register-total-label register-first-label">累计注册人数</label>
            <span class="data-total-value register-total-number">{{processData.totalNum|NumFormat}}</span>

          </div>
          <div v-if="processData.todayNum >= 0">
            <label class="register-total-label register-other-label">今日注册人数</label>
            <span class="data-total-value register-total-number">{{processData.todayNum|NumFormat}}</span>
            <div class="left-list-div">
              <i class="el-icon-caret-top green-icon" v-if="modelData.rate.nums"></i>
              <i class="el-icon-caret-bottom red-icon" v-if="!modelData.rate.nums"></i>
              <span :class="modelData.rate.nums?'data-percent-number-up':'data-percent-number-down'">{{modelData.rateNum.nums}}</span>
              <label class="data-income-com">同比昨日</label>
            </div>
          </div>
          <div v-if="processData.totalBuyTime >= 0">
            <label class="register-total-label register-other-label">累计购买次数</label>
            <span class="data-total-value register-total-number">{{processData.totalBuyTime|NumFormat}}</span>
          </div>
          <div v-if="processData.todayBuyTime >= 0">
            <label class="register-total-label register-other-label">今日购买次数</label>
            <span class="data-total-value register-total-number">{{processData.todayBuyTime|NumFormat}}</span>
            <div class="left-list-div">
              <i class="el-icon-caret-top green-icon" v-if="processData.tbtRate"></i>
              <i class="el-icon-caret-bottom red-icon" v-if="!processData.tbtRate"></i>
              <span :class="processData.tbtRate?'data-percent-number-up':'data-percent-number-down'">{{processData.tbtRateNum}}</span>
              <label class="data-income-com">同比昨日</label>
            </div>
          </div>
          <div v-if="processData.totalBuyNum >= 0">
            <label class="register-total-label register-other-label">累计购买人数</label>
            <span class="data-total-value register-total-number">{{processData.totalBuyNum|NumFormat}}</span>
          </div>
          <div v-if="processData.todayBuyNum >= 0">
            <label class="register-total-label register-other-label">今日购买人数</label>
            <span class="data-total-value register-total-number">{{processData.todayBuyNum|NumFormat}}</span>
            <div class="left-list-div">
              <i class="el-icon-caret-top green-icon" v-if="processData.tbnRate"></i>
              <i class="el-icon-caret-bottom red-icon" v-if="!processData.tbnRate"></i>
              <span :class="processData.tbnRate?'data-percent-number-up':'data-percent-number-down'">{{processData.tbnRateNum}}</span>
              <label class="data-income-com">同比昨日</label>
            </div>
          </div>
          <div v-if="modelData.sumToday && modelData.sumToday.app >= 0">
            <label class="register-total-label register-other-label">APP-今日注册人数</label>
            <span class="data-total-value register-total-number">{{modelData.sumToday.app|NumFormat}}</span>
            <div class="left-list-div">
              <i class="el-icon-caret-top green-icon" v-if="modelData.rate.app"></i>
              <i class="el-icon-caret-bottom red-icon" v-if="!modelData.rate.app"></i>
              <span :class="modelData.rate.app?'data-percent-number-up':'data-percent-number-down'">{{modelData.rateNum.app}}</span>
              <label class="data-income-com ">同比昨日</label>
            </div>
          </div>
          <div v-if="modelData.sumToday && modelData.sumToday.web >= 0">
            <label class="register-total-label register-other-label">WEB-今日注册人数</label>
            <span class="data-total-value register-total-number">{{modelData.sumToday.web|NumFormat}}</span>
            <div class="left-list-div">
              <i class="el-icon-caret-top green-icon" v-if="modelData.rate.web"></i>
              <i class="el-icon-caret-bottom red-icon" v-if="!modelData.rate.web"></i>
              <span :class="modelData.rate.web?'data-percent-number-up':'data-percent-number-down'">{{modelData.rateNum.web}}</span>
              <label class="data-income-com">同比昨日</label>
            </div>
          </div>
          <div v-if="modelData.sumToday && modelData.sumToday.wap >= 0">
            <label class="register-total-label register-other-label">H5-今日注册人数</label>
            <span class="data-total-value register-total-number">{{modelData.sumToday.wap|NumFormat}}</span>
            <div class="left-list-div">
              <i class="el-icon-caret-top green-icon" v-if="modelData.rate.wap"></i>
              <i class="el-icon-caret-bottom red-icon" v-if="!modelData.rate.wap"></i>
              <span :class="modelData.rate.wap?'data-percent-number-up':'data-percent-number-down'">{{modelData.rateNum.wap}}</span>
              <label class="data-income-com ">同比昨日</label>
            </div>
          </div>
          <div v-if="modelData.sumToday && modelData.sumToday.vipPrice >= 0">
            <label class="register-total-label register-other-label">VIP-今日收入</label>
            <span class=" manage-in-money">￥{{modelData.sumToday.vipPrice|NumFormat}}</span>
            <div class="left-list-div">
              <i class="el-icon-caret-top green-icon" v-if="modelData.rate.vipPrice"></i>
              <i class="el-icon-caret-bottom red-icon" v-if="!modelData.rate.vipPrice"></i>
              <span :class="modelData.rate.vipPrice?'data-percent-number-up':'data-percent-number-down'">{{modelData.rateNum.vipPrice}}</span>
              <label class="data-income-com ''">同比昨日</label>
            </div>
          </div>
          <div v-if="modelData.sumToday && modelData.sumToday.douPrice >= 0">
            <label class="register-total-label register-other-label">青豆-今日收入</label>
            <span class=" manage-in-money">￥{{modelData.sumToday.douPrice|NumFormat}}</span>
            <div class="left-list-div">
              <i class="el-icon-caret-top green-icon" v-if="modelData.rate.douPrice"></i>
              <i class="el-icon-caret-bottom red-icon" v-if="!modelData.rate.douPrice"></i>
              <span :class="modelData.rate.douPrice?'data-percent-number-up':'data-percent-number-down'">{{modelData.rateNum.douPrice}}</span>
              <label class="data-income-com ''">同比昨日</label>
            </div>
          </div>
          <div v-if="modelData.sumToday && modelData.sumToday.bitPrice >= 0">
            <label class="register-total-label register-other-label">青币-今日收入</label>
            <span class=" manage-in-money">￥{{modelData.sumToday.bitPrice|NumFormat}}</span>
            <div class="left-list-div">
              <i class="el-icon-caret-top green-icon" v-if="modelData.rate.bitPrice"></i>
              <i class="el-icon-caret-bottom red-icon" v-if="!modelData.rate.bitPrice"></i>
              <span :class="modelData.rate.bitPrice?'data-percent-number-up':'data-percent-number-down'">{{modelData.rateNum.bitPrice}}</span>
              <label class="data-income-com ">同比昨日</label>
            </div>
          </div>
          <div v-if="modelData.sumToday && modelData.sumToday.qaPrice >= 0">
            <label class="register-total-label register-other-label">问吧-今日收入</label>
            <span class=" manage-in-money">￥{{modelData.sumToday.qaPrice|NumFormat}}</span>
            <div class="left-list-div">
              <i class="el-icon-caret-top green-icon" v-if="modelData.rate.qaPrice"></i>
              <i class="el-icon-caret-bottom red-icon" v-if="!modelData.rate.qaPrice"></i>
              <span :class="modelData.rate.qaPrice?'data-percent-number-up':'data-percent-number-down'">{{modelData.rateNum.qaPrice}}</span>
              <label class="data-income-com ">同比昨日</label>
            </div>
          </div>
          <!--<div v-if="numberList.spVal >= 0">
            <label class="register-total-label register-other-label">生涯测评-今日收入</label>
            <span class=" manage-in-money">￥{{numberList.spVal|NumFormat}}</span>
            <div class="left-list-div">
              <i class="el-icon-caret-top green-icon" v-if="isRise.todayBuyNum"></i>
              <i class="el-icon-caret-bottom red-icon" v-if="!isRise.todayBuyNum"></i>
              <span :class="isRise.todayBuyNum?'data-percent-number-up':'data-percent-number-down'">8%</span>
              <label class="data-income-com ''">同比昨日</label>
            </div>
          </div>
          <div v-if="numberList.zdVal >= 0">
            <label class="register-total-label register-other-label">志愿定制-今日收入</label>
            <span class=" manage-in-money">￥{{numberList.zdVal|NumFormat}}</span>
            <div class="left-list-div">
              <i class="el-icon-caret-top green-icon" v-if="isRise.todayBuyNum"></i>
              <i class="el-icon-caret-bottom red-icon" v-if="!isRise.todayBuyNum"></i>
              <span :class="isRise.todayBuyNum?'data-percent-number-up':'data-percent-number-down'">8%</span>
              <label class="data-income-com ''">同比昨日</label>
            </div>
          </div>-->
        </div>
      </el-col>
      <el-col :span="19" :class="modelData.title==='总收入'?'manage-height-spe':'manage-height-normal'">
        <div class="grid-content register-div">
          <div class="register-date-div">
            <span class="register-date" :class="checkDate.today?'date-blue-color':'date-normal-color'"
                  @click="changeCheckDate('today')">今日</span>
            <span class="register-date register-margin" :class="checkDate.week?'date-blue-color':'date-normal-color'"
                  @click="changeCheckDate('week')">本周</span>
            <span class="register-date register-margin" :class="checkDate.moon?'date-blue-color':'date-normal-color'"
                  @click="changeCheckDate('moon')">本月</span>
          </div>
          <div class="register-block" :class="modelData.opt && modelData.opt.plat && modelData.opt.type?'':'div-width'">
            <span class="choose-selected">选择日期：</span>
            <el-date-picker
              v-model="conditions.dateStart"
              type="date"
              placeholder="选择日期"
              size="mini"
              :clearable="false"
              :picker-options="pickerOptionsStart"
              @change="getNewData"
              value-format="yyyy-MM-dd">
            </el-date-picker>
            <span class="zhi-style">至</span>
            <el-date-picker
              v-model="conditions.dateEnd"
              type="date"
              placeholder="选择日期"
              size="mini"
              :clearable="false"
              :picker-options="pickerOptionsEnd"
              @change="getNewData"
              value-format="yyyy-MM-dd">
            </el-date-picker>
            <div class="div-inline" v-if="modelData.opt && modelData.opt.city">
              <span class="choose-selected">选择地区：</span>
              <el-select v-model="chooseArea" placeholder="请选择" size="mini" class="data-option">
                <el-option
                  v-for="item in this.modelData.option"
                  :key="item.city"
                  :label="item.index"
                  :value="item.city"
                >
                </el-option>
              </el-select>
            </div>
            <div class="div-inline" v-if="modelData.opt && modelData.opt.plat">
              <span class="choose-selected">选择平台：</span>
              <el-select v-model="choosePlat" placeholder="请选择" size="mini" class="data-option">
                <el-option
                  v-for="item in this.modelData.option"
                  :key="item.plat"
                  :label="item.index"
                  :value="item.plat"
                >
                </el-option>
              </el-select>
            </div>
            <div class="div-inline" v-if="modelData.opt && modelData.opt.type">
              <span class="choose-selected">选择类型：</span>
              <el-select v-model="chooseType" placeholder="请选择" size="mini" class="data-option">
                <el-option
                  v-for="item in this.modelData.option"
                  :key="item.type"
                  :label="item.index"
                  :value="item.type"
                >
                </el-option>
              </el-select>
            </div>
          </div>
          <div class="right-title-index" :class="modelData.title==='总收入'?'manage-height-spe':''">
            <el-row class="el-row-spe">
              <el-col :span="24" class="spe-el-col-height">
                <div>
                  <div v-if="processData.regNum">
                    <label class="register-point">·</label>
                    <label class="register-tip-label">该时间段注册人数</label>
                    <span class="register-tip-number">{{processData.regNum|NumFormat}}</span>
                  </div>
                  <div v-if="processData.sumPrice">
                    <label class="register-point">·</label>
                    <label class="register-tip-label">该时间段收入</label>
                    <span class="register-tip-number">{{processData.sumPrice|NumFormat}}</span>
                  </div>
                  <div v-if="processData.buyNum">
                    <label class="manage-point-buy">·</label>
                    <label class="register-tip-label manage-tip-buy">该时间段购买人数</label>
                    <span class="register-tip-number">{{processData.buyNum|NumFormat}}</span>
                  </div>
                  <div v-if="processData.buyTime">
                    <label class="manage-point-buy">·</label>
                    <label class="register-tip-label manage-tip-buy">该时间段购买次数</label>
                    <span class="register-tip-number">{{processData.buyTime|NumFormat}}</span>
                  </div>
                </div>
              </el-col>
            </el-row>
            <ve-line :data="chartData" :settings="chartSettings" :legend-visible="false"
                     :height="modelData.title==='总收入'?'500px':'360px'"
                     :class="modelData.title==='总收入'?'manage-chart-spe':''"></ve-line>
          </div>
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<script>
  export default {
    props: {
      modelData: {
        type: Object,
        required: true,
        default: {},
      }
    },
    computed: {
      processData() {
        switch (this.modelData.title) {
          case '注册统计'     :
            this.chartData.columns = ['dt', 'nums', 'app', 'web', 'wap'];
            this.newTip = ['日期', '注册人数', 'APP-注册人数', 'WEB-注册人数', 'H5-注册人数'];
            break;
          case '总收入'       :
            this.chartData.columns = ['dt', 'sumPrice', 'vipPrice', 'douPrice', 'bitPrice', 'qaPrice'];
            this.newTip = ['日期', '总收入', 'VIP-收入', '青豆-收入', '青币-收入', '问吧-收入',];
            break;
          case 'VIP购买数据'  :
            this.chartData.columns = ['dt', 'price', 'nums'];
            this.newTip = ['日期', 'VIP-收入', '购买人数'];
            break;
          case  '青豆购买数据' :
            this.chartData.columns = ['dt', 'price', 'nums'];
            this.newTip = ['日期', '青豆-收入', '购买人数'];
            break;
          case  '青币购买数据' :
            this.chartData.columns = ['dt', 'price', 'nums'];
            this.newTip = ['日期', '青币-收入', '购买人数'];
            break;
          case  '问吧购买数据' :
            this.chartData.columns = ['dt', 'price', 'nums'];
            this.newTip = ['日期', '问吧-收入', '购买人数'];
            break;
        }
        this.processList(this.modelData.list, this.newTip);
        this.sendLoading(this.modelData.index);
        this.loading = false;

        return this.dataFilter(this.modelData);
      },
    },
    data() {
      let label = {};
      this.chartSettings = {
        labelMap: label,
        area: true
      };
      const conditions = {'dateStart': '', 'dateEnd': '', 'chooseArea': '', 'choosePlat': ''};
      return {
        chooseType: '所有',
        chooseArea: '所有',
        choosePlat: '所有',
        label: label,//设定图表中的tooltip的显示标签
        checkDate: {today: false, week: true, moon: false},//控制今日、本周、本月
        rate: {},
        isRise: {},
        newTip: [],
        type: [],
        loading: true,
        conditions: conditions,
        //开始日期动态禁用日期
        pickerOptionsStart: {
          disabledDate(time) {
            let push = new Date(conditions.dateEnd);
            return time.getTime() > push;
          },
        },
        //结束日期动态禁用日期
        pickerOptionsEnd: {
          disabledDate(time) {
            let push = new Date(conditions.dateStart);
            return time.getTime() < push;
          },
        },
        chartData: {
          columns: [],
          rows: [{}]
        },

      }
    },
    methods: {
      /* 该方法用于将数据中意义相同的值有一个统一的命名
         1是注册统计特殊化命名;
         2是总收入特殊化命名;
         3是包含累计、今日、该时间段收入，今日收入比率数据的命名
         4是包含该时间段购买人数、累计购买人数、今日购买人数，比率数据的命名
         5是包含该时间段购买次数、累计购买次数、今日购买次数，比率数据的命名
       */
      dataFilter(data) {
        let newData = {}
        if (data.type) {
          this.type = data.type
        }
        if (this.type.includes(1)) {
          newData['regNum'] = data.sum.nums;
          newData['totalNum'] = data.sumAll.nums;
          newData['todayNum'] = data.sumToday.nums;
        }
        if (this.type.includes(2)) {
          newData['totalVal'] = data.sumAll.sumPrice;
          newData['todayVal'] = data.sumToday.sumPrice;
          newData['sumPrice'] = data.sum.sumPrice;
          newData['tvRateNum'] = data.rateNum.sumPrice;
          newData['tvRate'] = data.rate.sumPrice;
        }
        if (this.type.includes(3)) {
          newData['totalVal'] = data.sumAll.price;
          newData['todayVal'] = data.sumToday.price;
          newData['sumPrice'] = data.sum.price;
          newData['tvRateNum'] = data.rateNum.price;
          newData['tvRate'] = data.rate.price;
        }
        if (this.type.includes(4)) {
          newData['buyNum'] = data.sum.nums;
          newData['totalBuyNum'] = data.sumAll.nums;
          newData['todayBuyNum'] = data.sumToday.nums;
          newData['tbnRate'] = data.rate.nums;
          newData['tbnRateNum'] = data.rateNum.nums;
        }
        if (this.type.includes(5)) {
          newData['buyTime'] = data.sum.nums;
          newData['totalBuyTime'] = data.sumAll.nums;
          newData['todayBuyTime'] = data.sumToday.nums;
          newData['tbtRate'] = data.rate.nums;
          newData['tbtRateNum'] = data.rateNum.nums;
        }
        return newData;

      },
      getNewData() {
        if (this.conditions.dateEnd && this.conditions.dateStart) {
          this.loading = true;
          this.sendCondition(this.modelData.index, this.modelData.name, this.conditions.dateStart, this.conditions.dateEnd)
        }
      },
      // 该方法用于将图表中tooltip的展示条目命名个性化
      processList(list, data) {
        this.chartData.rows = list;
        data.forEach((item, index) => {
          this.label[this.chartData.columns[index]] = data[index];
        });
      },
      //向父组件传递条件
      sendCondition(index, name, startDate, endDate) {
        this.$emit("getConditions", index, name, startDate, endDate)
      },
      //向父组件传递数据加载情况
      sendLoading(sign) {
        this.$emit("getLoading", sign)
      },
      //点击今日、本周、本月触发的事件
      changeCheckDate(sign) {
        this.loading = true;
        switch (sign) {
          case 'today':
            this.checkDate.today = true;
            this.checkDate.week = false;
            this.checkDate.moon = false;
            this.conditions.dateStart = this.$moment().format('YYYY-MM-DD');//今天
            this.conditions.dateEnd = this.$moment().add(1, 'days').format('YYYY-MM-DD');//明天
            this.sendCondition(this.modelData.index, this.modelData.name, this.conditions.dateStart, this.conditions.dateEnd);
            break;
          case 'week':
            this.checkDate.today = false;
            this.checkDate.week = true;
            this.checkDate.moon = false;
            this.conditions.dateStart = this.$moment().startOf('isoWeek').format('YYYY-MM-DD');//周一日期
            this.conditions.dateEnd = this.$moment().endOf('isoWeek').format('YYYY-MM-DD');//周日日期
            this.sendCondition(this.modelData.index, this.modelData.name, this.conditions.dateStart, this.conditions.dateEnd);
            break;
          case 'moon':
            this.checkDate.today = false;
            this.checkDate.week = false;
            this.checkDate.moon = true;
            this.conditions.dateStart = this.$moment().startOf('month').format('YYYY-MM-DD');//本月开始日期
            this.conditions.dateEnd = this.$moment().endOf('month').format('YYYY-MM-DD');//本月结束日期
            this.sendCondition(this.modelData.index, this.modelData.name, this.conditions.dateStart, this.conditions.dateEnd);
            break;
        }
      },
    },
  }
</script>

<style lang="less" type="text/less" scoped>
  .commonMain {
    .el-row-component {
      overflow: hidden;
      max-height: 1000px
    }

    .choose-selected {
      font-size: 10px;
      margin-left: 10px
    }

    .left-list-div {
      margin-left: 11%
    }

    .right-title-index {
      z-index: 2;
    }

    .spe-el-col-height {
      height: 40px;
    }
  }
</style>
