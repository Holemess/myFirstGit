<template>
  <div class="main">
    <el-container>
      <!--<el-aside width="210px" v-for="list in listItems">
        <el-menu :default-openeds="['1', '3']">
          <template>
            <template slot="title">
              <i class="el-icon-message"></i>
              <span slot="title">{{list.mainTitle}}</span>
            </template>
            <el-menu-item-group>
              <el-menu-item index="1-1">
                <span slot="title">{{list.subTitle}}</span>
              </el-menu-item>
            </el-menu-item-group>
          </el-submenu>
          </template>
        </el-menu>
      </el-aside>-->

      <el-header>
        <span class="head-main-title">统计分析/</span>
        <span class="head-sub-title">数据观景台</span>
        <div class="header-float">
          <i class="el-icon-setting header-icon"></i>
          <span>admin</span>
        </div>
      </el-header>

      <el-main class="el-main-title">

        <show-chart :model-data="dataMarket" @getBigDataCon="getBigDataCon" v-loading="regLoading"></show-chart>

        <div class="mainTitle-top" :class="regTotal.open?'open':''">
          <span class="change-hand shrink-title" @click="togglePay(regTotal)">{{regTotal.mainTitle}}</span>
          <span @click="togglePay(regTotal)">
              <i class="el-icon-caret-bottom shrink-icon change-hand" :class="regTotal.open?'open':''"
                 v-if="regTotal.open"></i>
              <i class="el-icon-caret-top shrink-icon change-hand" :class="regTotal.open?'open':''"
                 v-if="!regTotal.open"></i>
          </span>
          <div class="menu-body menu-body-spe" v-loading="regLoading">
            <commonChart :model-data="regTotal.data" @getConditions="getConditions"
                         @getLoading="getLoading"></commonChart>
          </div>
        </div>

        <div class="mainTitle-top" :class="ecoTotal.open?'open':''">
          <span class="change-hand shrink-title " @click="togglePay(ecoTotal)">{{ecoTotal.mainTitle}}</span>
          <span @click="togglePay(ecoTotal)">
              <i class="el-icon-caret-bottom shrink-icon change-hand" :class="ecoTotal.open?'open':''"
                 v-if="ecoTotal.open"></i>
              <i class="el-icon-caret-top shrink-icon change-hand" :class="ecoTotal.open?'open':''"
                 v-if="!ecoTotal.open"></i>
          </span>
          <div class="menu-body menu-body-spe" v-for="economic in ecoTotal.data" :key="economic.index"
               v-loading="arrLoading.load">
            <commonChart :model-data="economic" @getConditions="getConditions" @getLoading="getLoading"></commonChart>
          </div>
        </div>

      </el-main>
    </el-container>
  </div>
</template>

<script>
  import commonChart from './commonChart.vue'
  import showChart from './showChart.vue'

  export default {
    components:{
      commonChart,
      showChart
    },
    data() {
      const conditions = {'dateStart': '', 'dateEnd': '', 'chooseMainArea': ''};
      const arrLoading = {};
      [0, 1, 2, 3, 4, 5].forEach(item => arrLoading[`${item}`] = {load: true});
      return {
        rate: {},
        regLoading: true,
        arrLoading: arrLoading,
        conditions: conditions,
        chooseMainArea: '所有',
        dataMarket: [],
        //自定义数据格式（主标题）
        regTotal: {mainTitle: '注册统计', open: true, data: {}},
        ecoTotal: {mainTitle: '经济统计', open: true, data: {'0': {}, '1': {}, '2': {}, '3': {}, '4': {}}},
      }
    },
    methods: {
      //数据大盘改变条件，获取注册统计数据和总收入数据(避免注册统计和总收入数据变化)
      changeData(dateStart, dateEnd) {
        Promise.all([
          this.$axios.get('/reg.go?startTime=' + dateStart + '&endTime=' + dateEnd + ''),
          this.$axios.get('/sum.go?startTime=' + dateStart + '&endTime=' + dateEnd + ''),
        ]).then(rs => {
          rs.forEach(item => {
            let data = item.data.data;
            this.creatRate(data.sum, data);

            data['rateNum'] = this.getPercent(data.sumToday, data.sumYesterday, Object.keys(data.sumToday), data);

            this.dataMarket.push(data);
          });
        });
      },
      //控制模块隐藏和展示
      togglePay(data) {
        data.open = !data.open;
        this.isChoose = !this.isChoose;
      },
      //给数据加上'rate'对象，用来判断同比昨日是增长还是减少(name:传输变量名，data为当前数据对象)
      creatRate(name, data) {
        this.rate = [];
        let attName = Object.keys(name);

        attName.forEach((item) => {
          if (item !== 'dt')
            this.rate[item] = true;

        });

        data['rate'] = this.rate;
      },
      //子组件传递的数据条件
      getConditions(index, name, startDate, endDate) {
        this.getData(index, name, startDate, endDate);
      },
      //子组件加载完成取消loading
      getLoading(index) {
        if (index !== '')
          this.arrLoading[index] = false;
        else {
          this.regLoading = false;
        }
      },
      //获取数据大盘条件
      getBigDataCon(startDate, endDate) {
        this.changeData(startDate, endDate);
      },
      //计算两个整数之间的百分比
      //today：{}今日数据对象，yesterday：{}昨日数据对象，sign：[]属性名数组，data：{}数据
      getPercent(today, yesterday, sign, data) {
        let get = {};
        let result = 0;

        sign.forEach((item) => {
          if (item !== 'dt') {//排除有日期数据项的干扰
            if (isNaN(today[item]) || isNaN(yesterday[item])) {
              get[item] = 0 + '%';
              data.rate[item] = true;
            } else if (today[item] === 0) {
              if (yesterday[item] !== 0) {
                get[item] = (yesterday[item] * 100) + '%';
                data.rate[item] = false;
              } else {
                get[item] = 0 + '%';
                data.rate[item] = true;
              }
            } else if (yesterday[item] === 0) {
              if (today[item] !== 0) {
                get[item] = (today[item] * 100) + '%';
                data.rate[item] = true;
              } else {
                get[item] = 0 + '%';
                data.rate[item] = true;
              }
            } else {
              today[item] = Math.round(today[item]);
              yesterday[item] = Math.round(yesterday[item]);
              result = Math.round(today[item] / yesterday[item] * 10000);
              if (result >= 10000) {
                result = result - 10000;
                data.rate[item] = true;
              } else {
                result = 10000 - result;
                data.rate[item] = false;
              }
              get[item] = (Math.round(result / 100) + '%');

            }
          }
        });
        return get
      },
      //统一获取数据
      getData(index, name, startTime, endTime) {
        let url = '/' + name + '.go?startTime=' + startTime + '&endTime=' + endTime;//通过变量获取地址
        this.$axios.get(url)
          .then(res => {
            let data = res.data.data;

            //title:子标题;type用于数据处理
            //option:选择器内容;opt:选择器的种类;
            switch (name) {
              case 'reg':
                data['title'] = '注册统计';
                data['option'] = [{city: '重庆', plat: 'APP'}, {city: '四川', plat: 'WEB'}, {city: '所有', plat: '所有'}];
                data['opt'] = {city: true, plat: true};
                data['type'] = [1];
                break;
              case 'sum':
                data['title'] = '总收入';
                data['option'] = [{city: '重庆', type: 'VIP'}, {city: '北京', type: '青豆'}, {city: '所有', type: '所有'}];
                data['opt'] = {city: true, type: true};
                data['type'] = [2];
                break;
              case 'vip':
                data['title'] = 'VIP购买数据';
                data['option'] = [{city: '重庆', plat: 'APP'}, {city: '四川', plat: 'WEB'}, {city: '所有', plat: '所有'}];
                data['opt'] = {city: true, plat: true};
                data['type'] = [3, 4];
                break;
              case 'dou':
                data['title'] = '青豆购买数据';
                data['option'] = [{city: '重庆'}, {city: '四川'}, {city: '所有'}];
                data['opt'] = {city: true};
                data['type'] = [3, 5];
                break;
              case 'bit':
                data['title'] = '青币购买数据';
                data['option'] = [{city: '重庆'}, {city: '上海'}, {city: '所有'}];
                data['opt'] = {city: true};
                data['type'] = [3, 5];
                break;
              case 'qa':
                data['title'] = '问吧购买数据';
                data['option'] = [{city: '重庆'}, {city: '上海'}, {city: '所有'}];
                data['opt'] = {city: true};
                data['type'] = [3, 5];
                break;

            }
            this.creatRate(data.sum, data);

            data['name'] = name;//传入数据的查询url的name
            data['index'] = index;//传入数据查询的顺序

            //将计算好的比例存入数据的新属性rateNum中
            data['rateNum'] = this.getPercent(data.sumToday, data.sumYesterday, Object.keys(data.sumToday), data);

            if (data.title === '注册统计') {
              this.regTotal.data = data;
            } else {
              this.ecoTotal.data[index] = data;
            }

          });
      },
    },
    created() {
      this.$axios.all(
        [this.getData('', 'reg', '2019-01-07', '2019-01-13'),
          this.getData('0', 'sum', '2018-06-20', '2018-06-26'),
          this.getData('1', 'vip', '2018-06-20', '2018-06-26'),
          this.getData('2', 'dou', '2018-06-20', '2018-06-26'),
          this.getData('3', 'bit', '2018-06-20', '2018-06-26'),
          this.getData('4', 'qa', '2018-06-20', '2018-06-26'),])
        .then(this.$axios.spread(function (acct, perms) {
        }));

      this.changeData('2018-06-20', '2018-06-26');
    }
  }
</script>

<style lang="less" type="text/less">
  body {
    background-color: rgb(244, 244, 244);
  }

  .main {
    min-width: 1240px;
    overflow-x: scroll;

    .mainTitle-top {
      margin-top: 30px;
    }

    .menu-body-spe {
      background-color: white;
      margin-top: 33px;
    }

    .header-float {
      float: right;
    }

    .header-icon {
      margin-right: 15px;
    }

    .div-inline {
      display: inline-block;
    }

    .div-width {
      width: 85%;
    }

    .el-row {
      margin-bottom: 20px;

      &:last-child {
        margin-bottom: 0;
      }
    }

    .bg-white {
      background: white;
      margin-top: 25px;
    }

    .grid-content {
      border-radius: 4px;
      min-height: 112px;
    }

    .date-blue-color {
      color: rgb(16, 142, 233);
    }

    .date-normal-color {
      color: black;
    }

    .el-collapse-item__header {
      background-color: rgb(244, 244, 244);
    }

    .shrink-icon {
      margin-left: 5px;
    }

    .shrink-title {
      font-size: 18px;
    }

    .change-hand {
      cursor: pointer;
    }

    .zhi-style {
      font-size: 10px;
      margin-left: 7px
    }

    .red-icon {
      color: red;
      margin-left: 6px
    }

    .green-icon {
      color: green;
      margin-left: 6px
    }

    /*el-header部分样式-star*/
    .el-header {
      color: #333;
      line-height: 60px;
      border: 1px solid #eee;
      font-size: 12px;
      background-color: white;
    }

    .head-main-title {
      color: rgb(214, 204, 214);
    }

    .head-sub-title {
      font-size: 20px;
      font-weight: bold;
      margin-left: 10px;
    }

    /*el-header部分样式-end*/
    /*el-数据大盘样式-star*/
    .el-main-title {
      width: 100%;
      overflow: hidden;
    }

    .data-main-div {
      padding-left: 65px;
      line-height: 30px
    }

    .data-block {
      float: right;
      width: auto;
    }

    .el-date-editor.el-input, .el-date-editor.el-input__inner {
      width: 152px;
    }

    .data-picker-end {
      margin-left: 5px;
      margin-right: 5px;
    }

    .data-option {
      width: 112px !important;
    }

    .data-today-label {
      font-size: 12px;
      color: rgb(152, 152, 152);
      padding-left: 6px;
    }

    .data-total-label {
      font-size: 12px;
      color: rgb(152, 152, 152);
      margin-left: 33%;
    }

    .data-today-value {
      font-size: 27px;
      color: rgb(102, 102, 102);
      display: block;
      min-width: 200px;
    }

    .data-total-value {
      font-size: 27px;
      color: rgb(102, 102, 102);
      margin-left: 28%;
      display: block;
      min-width: 225px;
    }

    .data-today-number {
      margin-left: 6px;
    }

    .data-total-number {
      margin-left: 32%;
    }

    .data-percent {
      margin-left: 75px;
    }

    .data-percent-number-down {
      font-size: 10px;
      min-width: 35px;
      display: inline-block;
      color: red;
    }

    .data-percent-number-up {
      font-size: 10px;
      min-width: 35px;
      display: inline-block;
      color: green;
    }

    .data-income-com {
      font-size: 12px;
      color: rgb(152, 152, 152);
    }

    .data-div {
      padding-top: 10px;
    }

    /*el-数据大盘样式-end*/

    /*el-注册统计样式-star*/
    .register-div {
      border-left: rgb(235, 235, 235) 1px solid;
      height: 100%;
    }

    .register-first-label {
      margin-top: 26px;
      display: block;
    }

    .register-other-label {
      margin-top: 18px;
      display: block;
    }

    .register-total-label {
      font-size: 12px;
      color: rgb(152, 152, 152);
      margin-left: 14%;
    }

    .register-total-number {
      margin-left: 14%;
      display: block;
      height: 32px;
      max-width: 180px;
      overflow: hidden;
    }

    .register-block {
      margin-top: 27px;
      float: right;
      position: relative;
      z-index: 10;
      margin-right: 8px;
    }

    .register-date {
      font-size: 10px;
      cursor: pointer;
    }

    span.register-date:hover {
      color: rgb(16, 142, 233);
    }

    .register-date-div {
      float: left;
      margin-top: 28px;
      margin-left: 21px;
      z-index: 10;
      position: relative;
    }

    .register-margin {
      margin-left: 10px;
    }

    .register-tip-label {
      font-size: 13px;
      color: #989898;
      display: block;
      float: left;
      margin-top: 18px;
      margin-left: 10px;
    }

    .register-tip-number {
      font-size: 16px;
      display: block;
      float: left;
      margin-top: 16px;
      margin-left: 12px;
      min-width: 100px;
    }

    .register-point {
      font-size: 38px;
      float: left;
      margin-left: 20px;
      color: rgb(152, 152, 152);
    }

    /*el-注册统计样式-end*/

    /*el-经营统计样式-star*/
    .manage-title {
      border-bottom: rgb(235, 235, 235) 1px solid;
      height: 50px;
    }

    .manage-title-span {
      font-size: 16px;
      margin-left: 21px;
      margin-top: 15px;
      font-weight: bold;
      color: rgb(102, 102, 102);
      display: flex;
    }

    .manage-in-money {
      margin-left: 11%;
      font-size: 27px;
      color: rgb(102, 102, 102);
      display: block;
      height: 29px;
    }

    .manage-point-buy {
      font-size: 38px;
      float: left;
      margin-left: 22px;
      color: rgb(152, 152, 152);
    }

    .manage-tip-buy {
      margin-top: 18px;
    }

    .manage-height-spe {
      height: 650px;
    }

    .manage-height-normal {
      height: 440px;
    }

    .manage-chart-spe {
      padding-top: 60px;
    }

    .el-row-spe {
      margin-bottom: 0;
    }

    /*el-经营统计样式-end*/
  }

  /*.el-aside {
    display: block;
    position: absolute;
    left: 0;
    top:0;
    bottom: 0;
    overflow-y: visible;
    border:1px solid #eee;
    color:#333;
  }*/
</style>
