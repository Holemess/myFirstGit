<template>
  <div>
    <div :class="bigData.open?'open':''">
      <span class="change-hand shrink-title" @click="togglePay(bigData)">{{bigData.mainTitle}}</span>
      <span @click="togglePay(bigData)">
              <i class="el-icon-caret-bottom shrink-icon change-hand" :class="bigData.open?'open':''"
                 v-if="bigData.open"></i>
              <i class="el-icon-caret-top shrink-icon change-hand" :class="bigData.open?'open':''"
                 v-if="!bigData.open"></i>
           </span>
      <div class=" menu-body data-block">
        <span class="choose-selected">选择日期：</span>
        <el-date-picker
          v-model="conditions.dateStart"
          type="date"
          placeholder="选择日期"
          size="mini"
          :clearable="false"
          @change="changeData"
          :picker-options="pickerOptionsStart"
          value-format="yyyy-MM-dd">
        </el-date-picker>
        <span class="zhi-style">至</span>
        <el-date-picker
          v-model="conditions.dateEnd"
          placeholder="选择日期"
          size="mini"
          :clearable="false"
          @change="changeData"
          :picker-options="pickerOptionsEnd"
          value-format="yyyy-MM-dd">
        </el-date-picker>
        <span class="choose-selected">选择地区：</span>
        <el-select v-model="chooseMainArea" placeholder="请选择" size="mini" class="data-option">
          <el-option
            v-for="item in options"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          >
          </el-option>
        </el-select>
      </div>
      <div class="menu-body" v-loading="loading">
        <el-row :gutter="40">
          <el-col :span="12">
            <div class="grid-content bg-white data-main-div">
              <el-row :gutter="45">
                <el-col :span="9">
                  <div class="grid-content data-div">
                    <label class="data-today-label">今日总收入</label>
                    <span class="data-today-value">￥{{processData.todayIncome|NumFormat}}</span>
                    <i class="el-icon-caret-top green-icon" v-if="processData.isRiseVal"></i>
                    <i class="el-icon-caret-bottom red-icon" v-if="!processData.isRiseVal"></i>
                    <span
                      :class="processData.isRiseVal?'data-percent-number-up':'data-percent-number-down'">{{processData.percentVal}}</span>
                    <label class="data-income-com">同比昨日</label>
                  </div>
                </el-col>
                <el-col :span="9">
                  <div class="grid-content data-div">
                    <label class="data-total-label">累计总收入</label>
                    <span class="data-total-value">￥{{processData.totalIncome|NumFormat}}</span>
                  </div>
                </el-col>
              </el-row>
            </div>
          </el-col>
          <el-col :span="12">
            <div class="grid-content bg-white data-main-div">
              <el-row :gutter="40">
                <el-col :span="8">
                  <div class="grid-content data-div">
                    <label class="data-today-label ">今日注册人数</label>
                    <span class="data-today-value data-today-number">{{processData.todayNum|NumFormat}}</span>
                    <i class="el-icon-caret-top green-icon" v-if="processData.isRiseNum"></i>
                    <i class="el-icon-caret-bottom red-icon" v-if="!processData.isRiseNum"></i>
                    <span
                      :class="processData.isRiseNum?'data-percent-number-up':'data-percent-number-down'">{{processData.percentNum}}</span>
                    <label class="data-income-com">同比昨日</label>
                  </div>
                </el-col>
                <el-col :span="9">
                  <div class="grid-content data-div">
                    <label class="data-total-label">累计注册人数</label>
                    <span class="data-total-value data-total-number">{{processData.totalNum|NumFormat}}</span>
                  </div>
                </el-col>
              </el-row>
            </div>
          </el-col>
        </el-row>
      </div>
    </div>

  </div>
</template>

<script>
  export default {
    props: {
      modelData: {
        type: Array,
        required: true,
        default: [],
      },
    },
    computed: {
      processData() {
        this.loading = false;
        this.modelData.forEach(data => {
          if (data.sumAll.nums) {
            this.showData['totalNum'] = data.sumAll.nums;
            this.showData['todayNum'] = data.sumToday.nums;
            this.showData['percentNum'] = data.rateNum.nums;
            this.showData['isRiseNum'] = data.rate.nums;
          } else {
            this.showData['totalIncome'] = data.sumAll.sumPrice;
            this.showData['todayIncome'] = data.sumToday.sumPrice;
            this.showData['percentVal'] = data.rateNum.sumPrice;
            this.showData['isRiseVal'] = data.rate.sumPrice;
          }
        })
        return this.showData
      }
    },
    data() {
      const conditions = {'dateStart': '', 'dateEnd': '', 'chooseMainArea': ''};
      return {
        loading: true,
        showData: {},
        chooseMainArea: '所有',
        conditions: conditions,
        bigData: {mainTitle: '数据大盘', open: true},
        options: [
          {value: '选项1', label: '重庆'},
          {value: '选项2', label: '四川'},
          {value: '选项3', label: '所有'}
        ],
        pickerOptionsStart: {
          disabledDate(time) {
            let push = new Date(conditions.dateEnd);
            return time.getTime() > push;
          },
        },
        pickerOptionsEnd: {
          disabledDate(time) {
            let push = new Date(conditions.dateStart);
            return time.getTime() < push;
          },
        },
      }
    },

    methods: {
      //向父组件传递条件
      sendCondition(startDate, endDate) {
        this.$emit("getBigDataCon", startDate, endDate)
      },
      changeData() {
        if (this.conditions.dateEnd && this.conditions.dateStart) {
          this.loading = true;
          this.sendCondition(this.conditions.dateStart, this.conditions.dateEnd)
        }
      },
      //控制模块隐藏和展示
      togglePay(data) {
        data.open = !data.open;
        this.isChoose = !this.isChoose;
      },
    }
  }
</script>

<style scoped>

</style>
