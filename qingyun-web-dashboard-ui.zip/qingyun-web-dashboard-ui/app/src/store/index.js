const debug = process.env.NODE_ENV !== 'product';
import Vuex from 'Vuex'
export default new Vuex.Store({
  //定义初始数据
  state:{
    modelData:[],
    /*currentView: 'region',*/
  },
  mutations: {
    //向state 里面设置数据
    changeListMutation(state, data) {
      state.modelData = data
    },
    /*setView (state, currentView) {
      // 变更状态
      state.currentView = currentView;
    }*/
  },
  /*actions:{
    getListAction(state,item) {
      this.$axios.get('/reg.go?startTime=2019-01-07&endTime=2019-01-13')
        .then((res) => {
          const data = res.data;
          state.modelData = data;
          console.log(data)
        })
        .catch((error) => {
          console.log(error)
        })
    }
  },*/
  strict: debug,
})
