// 导入自己需要的组件
import VeLine from 'v-charts/lib/line.common';

const vCharts = {
  install: function (Vue) {
    Vue.component(VeLine.name, VeLine);
  }
};

export default vCharts;
